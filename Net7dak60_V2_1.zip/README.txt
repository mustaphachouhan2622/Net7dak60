Net7dak 60 V2.1 — 100 unique questions, 60-second timer, score, best score, daily challenge, ad placeholder.
